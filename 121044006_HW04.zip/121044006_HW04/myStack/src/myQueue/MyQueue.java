package myQueue;

import java.util.*;

/**
 * Created by egc on 3/22/2017.
 */
public class MyQueue<E> extends KWLinkedList<E>  {

    /**
     * Constractor
     */
    public MyQueue(){

        super();
    }

    /**
     * Bu method iterator kullanarak myQueue objesinin
     * elemanlarini reverse yapar.
     * Bu method next i null olana kadar next i basa ekler ve oldugu yerden siler.
     */
    public void reverseMyQ(){
       /* ListIterator<E> iter =this.listIterator(this.getSize());
        while (iter.hasPrevious()) {
            this.offer(iter.previous());
            iter.remove();
        }
        */
         ListIterator<E> iter =this.listIterator();
            while (iter.hasNext()) {
                this.addFirst(iter.next());
                iter.remove();
            }

    }

    /**
     * Bu method recursive olarak Queue nun elemanlarini reverse yapar.
     * @param theQueue Queue objesi
     */
    public void reverseQ(Queue<E> theQueue){
        E temp= theQueue.poll();

        reverseQu(theQueue,temp);
        temp = theQueue.poll();
        theQueue.offer(temp);
    }

    /**
     * Wrapper  method to reverse Queue
     * @param theQueue Queue ilk elemandan sonrasi
     * @param element eklenilen element
     */
    private void reverseQu(Queue<E> theQueue,E element){
        E temp = theQueue.poll();

        if(!theQueue.isEmpty()) {
            reverseQu(theQueue, element);

        }else
            theQueue.offer(element);

        theQueue.offer(temp);
    }

    /**
     * Bu method data yi Queue nun sonuna ekler.
     * @param item element
     * @return boolean true
     */
    public boolean offer(E item){
        this.addLast(item);
        return true;
    }

    /**
     * Bu method Queue nun basindan siler
     * @return removed element
     */
    public E poll(){
        ListIterator<E> iter =this.listIterator();
        E temp=null;

            if(iter.hasNext()){
                temp=iter.next();
                iter.remove();
                return temp;
            }


        return temp;
    }

    /**
     * Bu method ilk elemani return eder.
     * @return first item
     */
    public E peek(){
        ListIterator iter =this.listIterator();
        if(iter.next() == null)
            return null;
        return this.getFirst();
    }

    /**
     * toString
     * @return String
     */
    @Override
    public String toString(){
        ListIterator<E> iter =this.listIterator();
        StringBuilder str = new StringBuilder();
        E temp;
        try {
            temp = iter.next();
            str.append(temp);
            while ((temp = iter.next()) != null)
               str.append(","+temp);
            str.append("\n");
        }catch(NoSuchElementException e){
            return str.toString();
        }
        return str.toString();
    }


}
