package myQueue;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Created by egc on 3/23/2017.
 */
public class TestMain<E> {


    public static void main(String []args) throws IOException{

        {
            MyQueue theQueue = new MyQueue();

            theQueue.offer("str1");
            theQueue.offer("str2");
            theQueue.offer("str3");
            theQueue.offer("str4");
            theQueue.offer("str5");

            System.out.println("****** All Tests Of My Queue methods *******");
            System.out.println("Test Of The Offer() Method Added Elements\n"+theQueue.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Peek Method Returned First Element >> "+theQueue.peek());
            System.out.println("Test Of The Peek() Method Not Removed First Element \n"+theQueue.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Poll Method Returned First Element >> "+theQueue.poll());
            System.out.println("Test Of The Poll() Method Removed First Element  \n"+theQueue.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Reverse() My Queue Method");
            System.out.println("Queue Content >> "+theQueue.toString());
            theQueue.reverseMyQ();
            System.out.println("Reversed Queue >> "+theQueue.toString());
            System.out.println("------------------------------------------\n");
            Queue queue = new LinkedList();

            queue.offer("str6");
            queue.offer("str7");
            queue.offer("str8");
            queue.offer("str9");
            queue.offer("str10");
            System.out.println("Test Of The Reverse() Queue Method");
            System.out.println("Queue Content >> "+queue.toString());
            theQueue.reverseQ(queue);
            System.out.println("Reversed Queue >> "+queue.toString());
            System.out.println("------------------------------------------\n");
        }

        {

            FileReader in = null;
            FileWriter out = null;

            ArrayList<Queue> allQueues=new ArrayList<>();
            ArrayList<MyQueue> allMyQueues=new ArrayList<>();

            MyQueue myQueue=new MyQueue();
            Queue queue;

            String line = "";
            String cvsSplitBy = ",";

            try {
                in = new FileReader("test.csv");
                out = new FileWriter("testResult_2.csv");

                BufferedReader br = new BufferedReader(in);

                while ((line = br.readLine()) != null) {
                     myQueue=new MyQueue();
                     queue = new LinkedList();

                    String[] token = line.split(cvsSplitBy);

                    for (int i = 0; i < token.length; ++i) {

                        if (isNumeric(token[i])) {  //number

                            float y = Float.parseFloat(token[i]);
                            int x = (int)y;

                            if (y == x) {     // num is integer

                                myQueue.offer(x);
                                queue.offer(x);
                            } else {                 // num is float

                                myQueue.offer(y);
                                queue.offer(y);

                            }

                        } else if (isCharacter(token[i])) { // character

                            char chr = token[i].charAt(0);

                            myQueue.offer(chr);
                            queue.offer(chr);

                        } else {                           // string
                            // System.out.println("string > "+token[i]);
                            myQueue.offer(token[i]);
                            queue.offer(token[i]);
                        }
                    }
                    allMyQueues.add(myQueue);
                    allQueues.add(queue);
                    //System.out.println(myQueue.toString());
                    //System.out.println(queue.toString());
                }


                for(int i=0;i<allMyQueues.size();i++) {
                   allMyQueues.get(i).reverseMyQ();
                }
                for(int i=allMyQueues.size()-1;i>=0;i--){
                    out.append("\n");
                    out.append(allMyQueues.get(i).getSize()+","+allMyQueues.get(i).toString());
                }

                for(int i=0;i<allQueues.size();i++) {
                   myQueue.reverseQ(allQueues.get(i));
                }
                for(int i=allQueues.size()-1;i>=0;i--){
                    out.append("\n");
                    out.append(allQueues.get(i).size()+","+allQueues.get(i).toString());
                }


            } catch (IOException e) {

                e.printStackTrace();

            } finally {
                if (in != null)
                    in.close();

                if (out != null)
                    out.close();

            }
        }


    }

    public static boolean isNumeric(String str) {
        try {
            float y = Float.parseFloat(str);
            //System.out.println("check > "+Long.parseLong(text));
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }
    public static boolean isCharacter(String str){
        if(str.length() == 1 )
            if(str.charAt(str.length()-1) >= 'a' && str.charAt(str.length()-1) <= 'z')
                return true;
        return false;
    }




}


