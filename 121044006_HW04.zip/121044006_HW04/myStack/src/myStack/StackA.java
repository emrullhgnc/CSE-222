package myStack;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * Created by egc on 3/21/2017.
 */
public class StackA<E> extends ArrayList<E>  implements StackInterface<E> {

     public StackA(){
         super();
     }

    /**
     * @see myStack.StackInterface#push(Object)
     *
     */
    @Override
    public E push(E obj) {
        super.add(0,obj);
        return obj;
    }

    /**
     *
     * @see StackInterface#pop()
     */
    @Override
    public E pop() {
        if(isEmpty()){
            throw new EmptyStackException();
        }
        return super.remove(0);
    }

    /**
     * @see StackInterface#size()
     *
     */
    @Override
    public int size(){

        return super.size();
    }

    /**
     *
     * @see StackInterface#isEmpty()
     */
    @Override
    public boolean isEmpty() {
        return super.size() == 0;
    }

    /**
     * Bu method veri yapisindaki datalari  CSV file a yazar.
     * Veri yapisindaki datalari dosyaya FIFO prensibiyle yazdirdim.
     * @param out output file pointer
     */
    public void appendToCsv(FileWriter out){

        LinkedList<E> temp= new LinkedList<E>();

        while(!super.isEmpty())
            temp.addFirst(super.remove(super.size()-1));
            //temp.addFirst(super.remove(super.size()-1));


        for(int i=0;i<temp.size();i++)
           super.add(temp.get(i));

        try{
            out.append("\n");
            out.append(String.valueOf(super.size()));
            for(int i=temp.size()-1;i>=0;i--){
                out.append(",");
                out.append(String.valueOf(temp.get(i)));

            }
           // out.append("\n");
        } catch (IOException e) {

            e.printStackTrace();

        }

    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();

        try {
            str.append((this.get(0)));
            for (int i = 1; i<size(); i++)
               str.append(","+this.get(i));

        }
        catch ( EmptyStackException ignored){}
        return str.toString();
    }
}
