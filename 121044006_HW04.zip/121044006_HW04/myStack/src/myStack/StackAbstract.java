package myStack;

import java.io.FileWriter;
import java.io.IOException;
import java.util.EmptyStackException;
import java.util.LinkedList;

/**
 * Created by egc on 3/22/2017.
 */
public abstract class StackAbstract<E> implements StackInterface<E> {

    /**
     * @see myStack.StackInterface#push(Object)
     *
     */
    @Override
    public abstract  E push(E obj);

    /**
     *
     * @see StackInterface#pop()
     */
    @Override
    public abstract E pop();

    /**
     *
     * @see StackInterface#isEmpty()
     */
    @Override
    public abstract boolean isEmpty() ;

    /**
     * @see StackInterface#size()
     *
     */
    @Override
    public abstract int size() ;

    /**
     * Bu method u Subclass lar kullanmaktadir.
     * Bu method veri yapisindaki datalari  CSV file a yazar.
     * Veri yapisindaki datalari dosyaya FIFO prensibiyle yazdirdim.
     * @param out output file pointer
     */
    public void appendToCsv(FileWriter out){

        LinkedList<E> temp= new LinkedList<E>();

        while(!this.isEmpty())
            temp.addFirst(this.pop());


        for(int i=0;i<temp.size();i++)
            this.push(temp.get(i));

        try{
            out.append("\n");
            out.append(String.valueOf(this.size()));
            for(int i=0;i<temp.size();i++){
                out.append(",");
                out.append(String.valueOf(temp.get(i)));

            }
           // out.append("\n");
        } catch (IOException e) {

            e.printStackTrace();

        }

    }


}
