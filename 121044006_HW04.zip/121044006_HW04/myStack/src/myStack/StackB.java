package myStack;

import java.util.ArrayList;
import java.util.EmptyStackException;

/**
 * Created by egc on 3/21/2017.
 */
public class StackB<E> extends StackAbstract<E> {

    private ArrayList<E> theData;

    public StackB(){
        theData=new ArrayList<E>();
    }


    /**
     * ArrayList add(index,item) method u kullanarak
     * stack in en ustune ekleme yapar.
     *
     * @see myStack.StackInterface#push(Object)
     *
     */
    @Override
    public E push(E obj) {
        theData.add(0,obj);
        return obj;
    }

    /**
     *
     * @see StackInterface#pop()
     */
    @Override
    public E pop() {
        if(isEmpty()){
            throw new EmptyStackException();
        }
        return theData.remove(0);
    }

    /**
     * @see StackInterface#size()
     *
     */
    @Override
    public int size() {
        return theData.size();
    }

    /**
     *
     * @see StackInterface#isEmpty()
     */
    @Override
    public boolean isEmpty() {
        return theData.size() == 0;
    }

    /**
     * toString method
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();

        try {
            str.append(theData.get(0));
            for (int i = 1; i <this.size(); i++)
                str.append(","+theData.get(i));

        }
        catch ( EmptyStackException ignored){}
        //return theData.toString();
        return str.toString();
    }
}
