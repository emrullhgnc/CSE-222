package myStack;

import java.util.EmptyStackException;
import java.util.Iterator;

/**
 * Created by egc on 3/21/2017.
 */
public class StackC<E> extends StackAbstract<E> {

    private Node<E> topOfStackRef = null;

    private int size;

    /**
     * inner class
     * @param <E> Node class type Enum
     */
    private static class Node<E>{
        /**
         * tutulan data
         */
        private E data;
        /**
         * Bir sonraki Node u tutar
         */
        private Node<E> next;

        /**
         * Constractor
         * @param dataItem
         */
        private Node(E dataItem){
            data =dataItem;
            next=null;
        }

        /**
         *
         * Constractor
         * @param dataItem eklenilecek data
         * @param nodeRef sonraki Node u tutar
         */
        private Node(E dataItem,Node<E> nodeRef){
            data=dataItem;
            next=nodeRef;
        }

        public E getData() {
            return data;
        }
    }

    /**
     * Bu method yeni node olusturarak head a ekler.
     * @param obj eklenen data
     * @return eklenen data
     */
    @Override
    public E push(E obj) {
        topOfStackRef = new Node<E>(obj,topOfStackRef);
        size++;
        return obj;

    }

    /**
     * Bu method head deki node u silerek return eder.
     * @return head
     */
    @Override
    public E pop() {
        if(isEmpty())
            throw new EmptyStackException();
        else{
            E result = topOfStackRef.data;
            topOfStackRef = topOfStackRef.next;
            size--;
            return result;
        }

    }
    /**
     * @see StackInterface#size()
     *
     */
    @Override
    public int size() {
        return this.size;
    }
    /**
     * @see StackInterface#isEmpty()
     *
     */
    @Override
    public boolean isEmpty() {
        return topOfStackRef == null;
    }

    /**
     * toString
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        Node<E> node=this.topOfStackRef;
        try {
            if(node !=null)
                str.append(node.data);
            node=node.next;
           while(node !=null) {
               str.append("," + node.data);
               node=node.next;
           }
        }
        catch ( EmptyStackException ignored){}
        return str.toString();
    }
}
