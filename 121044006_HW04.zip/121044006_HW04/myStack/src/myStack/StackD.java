package myStack;


import java.util.*;

/**
 * Created by egc on 3/21/2017.
 */
public class StackD<E> extends StackAbstract<E>   {

    private Queue<E> theQueue;


    public StackD(){
        theQueue=new LinkedList<E>();
    }

    /**
     * Bu method Queue yu kullanarak ekleme yapar.
     *
     * @see StackInterface#push(Object)
     *
     */
    @Override
    public E push(E obj) {

        Queue<E> temp=new LinkedList<E>();

        if (theQueue.isEmpty())
            theQueue.add(obj);
        else
        {
            while (!theQueue.isEmpty())
                temp.add(theQueue.remove());

            theQueue.add(obj);

            while (!temp.isEmpty())
                theQueue.add(temp.remove());
        }


        return obj;
    }

    /**
     * Bu method Queue methodunu kullanarak pop() yapar.
     * @see StackInterface#pop()
     *
     */
    @Override
    public E pop() {
        if(theQueue.isEmpty()){
            throw new EmptyStackException();
        }else
            return theQueue.poll();

    }
    /**
     * @see StackInterface#size()
     *
     */
    @Override
    public int size() {
        return theQueue.size();
    }
    /**
     * @see StackInterface#isEmpty()
     *
     */
    @Override
    public boolean isEmpty() {
        return theQueue.size() == 0;
    }

    /**
     * Queue nun to string methodu kullanilmistir.
     * @return string
     */
    @Override
    public String toString() {

        return theQueue.toString();
    }


}
