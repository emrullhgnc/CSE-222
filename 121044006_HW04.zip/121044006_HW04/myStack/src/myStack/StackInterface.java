package myStack;

/**
 * Created by egc on 3/21/2017.
 */
public interface StackInterface<E> {

    /**
     *Pushes an item onto the top of the stack and returns
     * the item pushed.
     * @param obj The object to be inserted
     * @return The object inserted
     */
    E push(E obj);

    /**
     * Returns the object at the top of the stack
     * and removes it.
     * post: The stack is one item smaller
     * @return The object at the top of the stack
     * @throws @EmptyStackException if stack is empty
     */
    E pop();

    /**
     * Returns size of the stack
     * @return The size of the stack
     */
    int size();

    /**
     * Return true if the stack is empty; otherwise,
     * returns false.
     * @return true if the stack is empty
     */
    boolean isEmpty();



}
