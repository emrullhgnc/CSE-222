package myStack;

import java.io.FileReader;

import java.io.FileWriter;

import java.io.BufferedReader;
import java.io.IOException;


/*
 * Created by egc on 3/21/2017.
 */
public class TestMain<E> {


    public static void main(String []args ) throws IOException{
        {


            StackA  stackA = new StackA();
            StackAbstract stackB = new StackB();
            StackAbstract stackC = new StackC();
            StackAbstract stackD = new StackD();


            stackA.push("A");
            stackA.push(2);
            stackA.push(3);
            stackA.push(4);

            System.out.println("****** All Tests Of My Stack methods *******");
            System.out.println("----------- Tests Of StackA ---------");
            System.out.println("Test Of The Push() Method Added Elements\n"+stackA.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Pop Method Returned Top Element(LIFO) >> "+stackA.pop());
            System.out.println("Test Of The Pop() Method Removed Top Element  \n"+stackA.toString());
            System.out.println("------------------------------------------\n");


            stackB.push("B");
            stackB.push(1);
            stackB.push(2);
            stackB.push(3);
            System.out.println("----------- Tests Of StackB ---------");
            System.out.println("Test Of The Push() Method Added Elements\n"+stackB.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Pop Method Returned Top Element(LIFO) >> "+stackB.pop());
            System.out.println("Test Of The Pop() Method Removed Top Element  \n"+stackB.toString());
            System.out.println("------------------------------------------\n");
            stackC.push("C");
            stackC.push(1);
            stackC.push(2);
            stackC.push(3);
            System.out.println("----------- Tests Of StackC ---------");
            System.out.println("Test Of The Push() Method Added Elements\n"+stackC.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Pop Method Returned Top Element(LIFO) >> "+stackC.pop());
            System.out.println("Test Of The Pop() Method Removed Top Element  \n"+stackC.toString());
            System.out.println("------------------------------------------\n");
            stackD.push('D');
            stackD.push(1);
            stackD.push(2);
            stackD.push(3);
            System.out.println("----------- Tests Of StackD ---------");
            System.out.println("Test Of The Push() Method Added Elements\n"+stackD.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("Test Of The Pop Method Returned Top Element(LIFO) >> "+stackD.pop());
            System.out.println("Test Of The Pop() Method Removed Top Element  \n"+stackD.toString());
            System.out.println("------------------------------------------\n");
        }
        {

            FileReader in = null;
            FileWriter out = null;

            StackA stackA;
            StackAbstract stackB;
            StackAbstract stackC;
            StackAbstract stackD;

            String line = "";
            String cvsSplitBy = ",";

            try {
                in = new FileReader("test.csv");
                out = new FileWriter("testResult_1.csv");

                BufferedReader br = new BufferedReader(in);

                while ((line = br.readLine()) != null) {
                   // System.out.println("read from file > "+line);
                     stackA = new StackA();
                     stackB = new StackB();
                     stackC = new StackC();
                     stackD = new StackD();

                    String[] token = line.split(cvsSplitBy);

                    for (int i = 0; i < token.length; ++i) {
                       // System.out.println("elements > "+token[i]);
                        if (isNumeric(token[i])) {  //number

                            float y = Float.parseFloat(token[i]);
                            int x = (int)y;

                            if (y == x) {     // num is integer
                                //System.out.println("integer > "+x);
                                stackA.push(x);
                                stackB.push(x);
                                stackC.push(x);
                                stackD.push(x);
                            } else {                 // num is float
                                //System.out.println("float > "+y);
                                stackA.push(y);
                                stackB.push(y);
                                stackC.push(y);
                                stackD.push(y);
                            }

                        } else if (isCharacter(token[i])) { // character

                            char chr = token[i].charAt(0);
                           // System.out.println("character > "+chr);
                            stackA.push(chr);
                            stackB.push(chr);
                            stackC.push(chr);
                            stackD.push(chr);
                        } else {                           // string
                           // System.out.println("string > "+token[i]);
                            stackA.push(token[i]);
                            stackB.push(token[i]);
                            stackC.push(token[i]);
                            stackD.push(token[i]);
                        }
                    }
                    stackA.appendToCsv(out);
                   // System.out.println(stackA);
                    stackB.appendToCsv(out);
                   // System.out.println(stackB);
                    stackC.appendToCsv(out);
                   // System.out.println(stackC);
                    stackD.appendToCsv(out);
                   // System.out.println(stackD);
                }

            } catch (IOException e) {

                e.printStackTrace();

            } finally {

                if (in != null) {
                    in.close();
                }

                if (out != null) {
                    out.close();
                }

            }


        }


    }



    public static boolean isNumeric(String str) {
        try {
            float y = Float.parseFloat(str);
            //System.out.println("check > "+Long.parseLong(text));
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    public static boolean isCharacter(String str){
        if(str.length() == 1 )
            if(str.charAt(0) >= 'a' && str.charAt(0) <= 'z' || str.charAt(0)>='A' && str.charAt(0) <='Z')
                return true;
        return false;
    }




}
