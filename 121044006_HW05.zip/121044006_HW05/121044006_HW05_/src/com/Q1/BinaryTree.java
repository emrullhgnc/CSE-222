package com.Q1;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.LinkedList;
/**
 * Created by egc on 3/31/2017.
 */


import java.io.Serializable;

/**
 * Class for a binary tree that stores type E objects.
 * @author Koffman and Wolfgang
 * @param <E> object
 **/
public class BinaryTree<E> implements Iterable<E>,Serializable {
  //  private
    /*<listing chapter="6" number="1">*/
    /** Class to encapsulate a tree node.
     * @param <E> object
     */
    protected static class Node<E>  {
        // Data Fields

        /** The information stored in this node. */
        public E data;
        /** Reference to the left child. */
        public Node<E> left;
        /** Reference to the right child. */
        public Node<E> right;
        /**Reference to the parent*/
        public Node<E> parent;
        // Constructors
        /**
         * Construct a node with given data and no children.
         * @param data The data to store in this node
         */
        public Node(E data) {
            this.data = data;
            parent=null;
            left = null;
            right = null;
        }
        public Node(E data,Node<E> parent) {
            this.data = data;
            this.parent=parent;
            left = null;
            right = null;
        }

        // Methods
        /**
         * Returns a string representation of the node.
         * @return A string representation of the data fields
         */
        @Override
        public String toString() {
            return data.toString();
        }
    }

    /*</listing>*/
    // Data Field
    /** The root of the binary tree */
    protected Node<E> root;

    /** Construct an empty BinaryTree */
    public BinaryTree() {
        root = null;
    }

    /**
     * Construct a BinaryTree with a specified root.
     * Should only be used by subclasses.
     * @param root The node that is the root of the tree.
     */
    protected BinaryTree(Node<E> root) {
        this.root = root;
    }

    /**
     * Constructs a new binary tree with data in its root,leftTree
     * as its left subtree and rightTree as its right subtree.
     * @param data object
     * @param leftTree object
     * @param rightTree object
     */
    public BinaryTree(E data, BinaryTree<E> leftTree,BinaryTree<E> rightTree) {
        root = new Node<E>(data);
        if (leftTree != null) {
            root.left = leftTree.root;
        } else {
            root.left = null;
        }
        if (rightTree != null) {
            root.right = rightTree.root;
        } else {
            root.right = null;
        }
    }
    public Node<E> getRoot(){
        return root;
    }

    //------------------------ START-MY-CODES---------

    protected class MyIterator<E> implements Iterator<E>{

        protected Node<E> next = (Node<E>)getRoot();


        @Override
        public boolean hasNext() {
            return next != null;
        }

        /**
         * Bu method pre order olarak Tree yi traverse eder.
         * next in Left i null olmadigi surece Left e ilerler
         * Left biterse Rigth a bakar.
         * eger node Leaf ise parent ina donerek
         * parent inin Right indaki veya Left indeki Node a bakarak ilerler.
         * @return E Type data
         */
        @Override
        public E next() {

            if (next == null)
                throw new NoSuchElementException();

            E data = next.data;



            if (next.left != null) {
                next = next.left;

            }else if (next.right != null){
                next = next.right;

            }
            else {

                Node parent = next.parent;
                Node child = next;

                while (parent != null &&(parent.right == child || parent.right == null)) {
                    child = parent;
                    parent = parent.parent;
                }

                if (parent == null){

                    next = null;
                }else {
                    next = parent.right;
                }
            }
            return data;
        }

    }

    @Override
    public Iterator<E> iterator() {
        return new MyIterator<E>();
    }



    /**
     * Perform a preorder traversal.
     */
    public  String preOrderTraverseWithIterator() {

        Iterator<E> iter= this.iterator();
        StringBuilder sb = new StringBuilder();

        try{
            while(iter.hasNext()){
                sb.append(iter.next());
                sb.append(" ");
            }
        }catch(NoSuchElementException e){
            e.printStackTrace();
        }
        return sb.toString();
    }



    /**
     * Add new element to Tree
     * @param data new element
     */
    public void insert(E data)
    {
        root = insert(root, data);

    }

    /**
     * Function to insert data recursively
     * @param node parent node
     * @param data new element
     * @return new element's node
     */
    private  Node<E> insert( Node<E> node,E data) {
        //if (data.node.data) {
        if (node == null){

            node = new Node<E>(data);
            node.parent=null;
        }
        else
        {
            if (node.left == null) {
                node.left = insert(node.left, data);
                node.left.parent=node;
            }else {
                node.right = insert(node.right, data);
                node.right.parent=node;
            }

        }
        return node;
    }



// ------------------- END-MY-CODES--------------------------------------------



    /**
     * Return the left subtree.
     * @return The left subtree or null if either the root or
     * the left subtree is null
     */
    public BinaryTree<E> getLeftSubtree() {
        if (root != null && root.left != null) {
            return new BinaryTree<E>(root.left);
        } else {
            return null;
        }
    }

    /**
     * Return the right sub-tree
     * @return the right sub-tree or
     *         null if either the root or the
     *         right subtree is null.
     */
    public BinaryTree<E> getRightSubtree() {
        if (root != null && root.right != null) {
            return new BinaryTree<E>(root.right);
        } else {
            return null;
        }
    }

    /**
     * Return the data field of the root
     * @return the data field of the root
     *         or null if the root is null
     */
    public E getData() {
        if (root != null) {
            return root.data;
        } else {
            return null;
        }
    }

    /**
     * Determine whether this tree is a leaf.
     * @return true if the root has no children
     */
    public boolean isLeaf() {
        return (root == null || (root.left == null && root.right == null));
    }

    /**
     *
     * @return string
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        preOrderTraverse(root, 1, sb);
        return sb.toString();
    }



    /**
     * Perform a preorder traversal.
     * @param node The local root
     * @param depth The depth
     * @param sb The string buffer to save the output
     */
    private void preOrderTraverse(Node<E> node, int depth,
                                  StringBuilder sb) {
        for (int i = 1; i < depth; i++) {
            sb.append("  ");
        }
        if (node == null) {
            sb.append("null\n");
        } else {
            sb.append(node.toString());
            sb.append("\n");

            preOrderTraverse(node.left, depth + 1, sb);
            preOrderTraverse(node.right, depth + 1, sb);

        }
    }







}
