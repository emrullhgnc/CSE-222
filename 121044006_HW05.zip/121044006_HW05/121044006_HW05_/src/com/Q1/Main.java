package com.Q1;
import java.io.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import com.Q1.BinaryTree.Node;
import com.Q2.FamilyTree;

public class Main implements Serializable {

    public static void main(String[] args) throws IOException {
        {
            //--------------------------------- PART-1.1 --------------------------------------

            BinaryTree tre = new BinaryTree();

            tre.root = new Node(1,null);
            tre.root.left = new Node(2,tre.getRoot());
            tre.root.left.left = new Node(6,tre.getRoot().left);
            tre.root.left.right = new Node(7,tre.getRoot().left);

            tre.root.right = new Node(3,tre.getRoot());
            tre.root.right.left = new Node(4,tre.getRoot().right);
            tre.root.right.right = new Node(5,tre.getRoot().right);

            System.out.println("******  Tests Of Question-1.1 *******");
            System.out.println("------------------------------------------\n");
            System.out.println("Get All Elements From Manual To Binary Tree\n");
            System.out.println("Display Binary Tree with toString\n"+tre.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("All Tree Elements PreOrder Traverse With Iterator\n"+tre.preOrderTraverseWithIterator());
            System.out.println("------------------------------------------\n");

        }

        {
            //--------------------------------- PART-1.1 --------------------------------------
            FileReader in = null;
            FileWriter out = null;

            BinaryTree tree = new BinaryTree();

            String line = "";

            try {
                in = new FileReader("test.txt");

                BufferedReader br = new BufferedReader(in);

                while ((line = br.readLine()) != null) {

                    tree.insert(line);
                }

            } catch (IOException e) {

                e.printStackTrace();

            } finally {
                if (in != null)
                    in.close();

                if (out != null)
                    out.close();

            }
            System.out.println("Read All Elements From File To Binary Tree\n");
            System.out.println("Display Binary Tree with toString \n"+tree.toString());
            System.out.println("------------------------------------------\n");
            System.out.println("All Tree Elements PreOrder Traverse With Iterator \n"+tree.preOrderTraverseWithIterator());
            System.out.println("------------------------------------------\n");
        }


        {
            //--------------------------------- PART-1.2 --------------------------------------
            BinarySearchTree bst = new BinarySearchTree();
            FileReader in = null;
            String line = "";

            try {
                in = new FileReader("test.txt");

                BufferedReader br = new BufferedReader(in);

                while ((line = br.readLine()) != null) {
                   bst.add(line);
                }

            } catch (IOException e) {

                e.printStackTrace();

            } finally {
                if (in != null)
                    in.close();
            }
            System.out.println("------------------------------------------\n");
            System.out.println("******  Tests Of Question-1.2 *******");
            System.out.println("------------------------------------------\n");
            System.out.println("Read All Elements From File To Binary Search Tree\n");
            System.out.println("Display Binary Search  Tree with toString ");
            System.out.println(bst.toString());

            System.out.println("------------------------------------------\n");
            System.out.println("Display Binary Search Tree with Level Order Traverse With Iterator()\n");
            bst.levelOrderTraverseWithIterator();
            System.out.println("------------------------------------------\n");


        }
        {
            //--------------------------------- PART-2 --------------------------------------
            FamilyTree family =new FamilyTree();


            FileReader in = null;



            String line = "";
            String cvsSplitBy = ",";

            try {
                in = new FileReader("family.txt");


                BufferedReader br = new BufferedReader(in);

                while ((line = br.readLine()) != null) {

                    String[] token = line.split(cvsSplitBy);

                    family.addPerson(token[0],token[1],token[2]);
                }


            } catch (IOException e) {

                e.printStackTrace();

            } finally {
                if (in != null)
                    in.close();
            }
            System.out.println("------------------------------------------\n");
            System.out.println("******  Tests Of Question-2 *******");
            System.out.println("------------------------------------------\n");
            System.out.println("Read All Elements From File To Family Tree\n");

            System.out.println("Family Tree Created\n"+family.toString());
            System.out.println("------------------------------------------\n");

        }

    }



}
