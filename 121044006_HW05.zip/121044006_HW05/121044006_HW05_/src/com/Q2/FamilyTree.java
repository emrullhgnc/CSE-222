package com.Q2;

/**
 * Created by egc on 4/5/2017.
 */
public class FamilyTree<E> extends BinaryTree<E>{
    /**
     * Constructs :kisi objesini family tree nin en basina  ekler
     * @param person eklenen kisi
     */
    public FamilyTree(E person){
        super.root=new Node<E>(person);
    }

    /**
     * Default Constructs
     */
    public FamilyTree(){
        super.root=null;
    }

    /**
     *
     * Wrapper method
     * Bu method Family Tree ye yeni kisi ekler.
     * @param name person name
     * @param pName parent's name
     * @param nickName parent's nickname
     * @return boolean True if success to add
     */
    public boolean addPerson(String name,String pName,String nickName){

        Node<E> newPerson=new Node<E>((E)name,(E)pName,(E)nickName);
        Node<E> nodeRef=root;

        if((root=addPerson(nodeRef,newPerson))==null)
            return false;

        return  true;
    }

    /**
     *
     * Bu method recursive yapiyi kullanarak Family Tree ye yeni kisi ekler.
     * Ekleme islemini kisinin bilgilerini kullanarak yapar.
     * Eklenecek kisi ilk cocuk veya kardes durumlarina gore yapilir.
     * Kisinin Parent i Tree de aranir varsa ve Tree nin left ine veya right ina gider.
     * @param nodeRef node referans her seferde next ini gonderir recursive call da.
     * @param newPerson node yeni kiside bulunan ozellikleri tasiyan Node
     * @return
     */
    private Node<E> addPerson(Node<E> nodeRef,Node<E> newPerson){
        if(nodeRef == null){

            nodeRef = new Node<E>(newPerson.name,newPerson.pName,null);
            return nodeRef;
        }else{
            if(nodeRef.left == null && newPerson.pName.equals(nodeRef.name)){

                nodeRef.left = addPerson(nodeRef.left,newPerson);

                if(nodeRef.nickName==null)
                    nodeRef.nickName=(E)newPerson.nickName;

            }else if(newPerson.pName.equals((nodeRef.name))){

                nodeRef.left=addPerson(nodeRef.left,newPerson);

                if(nodeRef.nickName==null)
                    nodeRef.nickName=(E)newPerson.nickName;

            }else if(newPerson.pName.equals(nodeRef.pName))

                nodeRef.right=addPerson(nodeRef.right,newPerson);

            else if(search((String) newPerson.pName,(String)newPerson.nickName,nodeRef.left))

                nodeRef.left=addPerson(nodeRef.left,newPerson);

            else if(search((String) newPerson.pName,(String)newPerson.nickName,nodeRef.right))

                nodeRef.right=addPerson(nodeRef.right,newPerson);

        }
        return nodeRef;
    }

    /**
     * Wrapper method
     * Bu method addPerson method unda eklenecek kisinin Parent i Tree de varmi diye arar.
     * Bu method,  Tree de belirli ozellikte Node  arar.
     * @param findName aranan Node un ismi
     * @param findNick aranan Node un nick name i
     * @param nodeRef Tree de dolasmak icin
     * @return boolean True if there is in tree
     */
    public boolean search(String findName,String findNick,Node nodeRef){

        Node result=searchPerson((E)findName,(E)findNick,nodeRef);

       if(result==null)
            return false;
       else
            return true;

    }

    /**
     * Bu method search yapar.
     * Tree nin once sol tarafinda arar bulursa return eder.
     * Bulamazsa sag tarafta arar.
     * Node un name ve nickname ozellikleri eslesiyorsa return Node yapar.
     * @param findName aranan Node un ismi
     * @param findNick aranan Node un nick name i
     * @param nodeRef Tree de dolasmak icin
     * @return
     */
    private Node searchPerson(E findName,E findNick, Node nodeRef)
    {

        Node result = null;
        if (nodeRef == null)
            return null;
        if (nodeRef.name.equals(findName) && (nodeRef.nickName==null ||findNick.equals(nodeRef.nickName)) )
            return nodeRef;
        if (nodeRef.left != null)

            result = searchPerson(findName,findNick,nodeRef.left);
        if (result == null)
            result = searchPerson(findName,findNick,nodeRef.right);

        return result;

    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        preOrderTraverse(root, 1, sb);
        return sb.toString();
    }



    /**
     * Perform a preorder traversal.
     * @param node The local root
     * @param depth The depth
     * @param sb The string buffer to save the output
     */
    private void preOrderTraverse(Node<E> node, int depth,
                                  StringBuilder sb) {
        for (int i = 1; i < depth; i++) {
            sb.append("  ");
        }
        if (node == null) {
            sb.append("null\n");
        } else {
            sb.append(node.toString()/*+" -- "+node.nickName*/);
            sb.append("\n");

            preOrderTraverse(node.left, depth + 1, sb);
            preOrderTraverse(node.right, depth + 1, sb);

        }
    }
}
